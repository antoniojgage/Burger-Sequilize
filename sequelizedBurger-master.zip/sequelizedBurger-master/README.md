# sequelizedBurger
Practice with Node, Express, Handlebars, and Sequelize
